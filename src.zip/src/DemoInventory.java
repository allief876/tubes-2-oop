import tubes.*;

import java.util.*;

public class DemoInventory {
        public static void main (String[] args) {
            Coordinate startingEngimon = new Coordinate(2,2);
            Engimon E1 = new Diglett("Test", startingEngimon, 1, false);
            System.out.println(E1.getElements());
            E1.displayInfo();

            Engimon E2 = new Rotom("Test", startingEngimon, 1, false);
            System.out.println(E2.getElements());
            E2.displayInfo();

        }
}
/*
            //Buat Engimonnya
            Coordinate startingEngimon = new Coordinate(2,1);
            int levelStarting = 10;
            Engimon E1 = new Squirtle("Demo1", startingEngimon, levelStarting);
            Engimon E2 = new Charmander("Demo2", startingEngimon, 5);
            Engimon E3 = new Charmander("Demo3", startingEngimon, 8);

            Inventory<Engimon> I = new Inventory<>();
            I.addItem(E1, 1);
            I.addItem(E2, 1);
            I.addItem(E3, 1);
            //System.out.println(I.getAmount(E1));
            //I.Entry();
            I.printInventory();

            //Buat Skillnya 
            ArrayList<String> element =  new ArrayList<String>();
            ArrayList<String> element1 =  new ArrayList<String>();
            element.add("Fire"); element.add("none");
            Skill S = new Skill(element,105,1,"Pyro Ball");
            element1.add("Water"); element1.add("none");
            Skill S1 = new Skill(element,75,1,"Waterfall");

            Inventory<Skill> InventSkill = new Inventory<>();
            InventSkill.addItem(S, 1);
            InventSkill.addItem(S1, 15);
            InventSkill.addItem(S, 2);
            InventSkill.printInventory();

    }
}
*/