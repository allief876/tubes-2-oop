import java.io.FileWriter; 
import java.io.IOException;

/**public class Save {
    // Semua properti dari yg lain
    public Save(Player P, String filename) {
        try {
            
        } catch (IOException e) {
            
        }
    }
}*/
